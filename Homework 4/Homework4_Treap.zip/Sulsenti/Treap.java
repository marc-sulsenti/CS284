package Sulsenti;
//Marc Sulsenti
//I pledge my honor that I have abided by the Stevens Honor System
import java.util.Random;
import java.util.Stack;
import java.util.ArrayList;
import java.util.*;


public class Treap<E extends Comparable<E>>{
    //E extends comparable <E> so we can use the compareTo function between Nodes
    public List<Integer> tracker = new ArrayList<>();
    /*The ArrayList tracker, will allow the program to keep track of all the priorities entered so far
    * and can later be used to ensure that there are no duplicates random generated. */
    private Random priorityGenerator;
    private Node<E> root;
    private static class Node<E> {
        public E data;
        public int priority;
        public Node<E> left;
        public Node<E> right;

        public Node(E data, int priority) {
            //Constructs a new node, with data and priority.
            //Constructor, checks if data is not null
            if (data == null) {
                throw new IllegalArgumentException("Data cannot be null.");
            }
            this.data = data;
            this.priority = priority;
            this.left = null;
            this.right = null;
        }

        //Rotators
        public Node<E> rotateRight() {
            //Rotate node Right
            Node<E> newRoot = this.left;
            this.left = newRoot.right;
            newRoot.right = this;
            return newRoot;
        }

        public Node<E> rotateLeft() {
            //Rotate node Left
            Node<E> newRoot = this.right;
            this.right = newRoot.left;
            newRoot.left = this;
            return newRoot;
        }

        public String toString() {
            //How an object of the Node Class should be printed out. As per HW4.PDF
            return "(key=" + data + ", priority=" + priority + ")";
        }
    }
    //end of node class
    //end of node class
    //end of node class

    public Treap() {
        //Constructor of a new Treap object with a null root, and random priority generator.
        //Random priority generated.
        this.priorityGenerator = new Random();
        this.root = null;
    }

    public Treap(long seed) {
        //This method of Treap, constructs a New Treap object with a randomized priority generator based off the seed.
        this.priorityGenerator = new Random(seed);
        this.root = null;
    }


    public boolean add(E key) {
        /* This add method generates the random priority, then sends that priority to the main add method.*/
        int priority = priorityGenerator.nextInt();
        while(tracker.contains(priority)){
            //ensures that nextInt is not somehow already a used priority.
            priority = priorityGenerator.nextInt();
        }
        return add(key,priority);
    }



    //add goes here
    public boolean add(E key, int priority) {
        /* This method adds a new node with a given priority to the tree. This will disorganize the heap property
        * of the tree, but the heap property of the tree will be restored with the helper function (reheap) */
        if(tracker.contains(priority)){
            //ensures no duplicate priorities get added to the tree,per the directions.
            throw new IllegalArgumentException("Can not have duplicated priorities.");
        }
        if(root == null) {
            //If the root is null, then we are adding the node to be the new root.
            root = new Node<E>(key, priority);
            tracker.add(priority);
            return true;
        }else {
            /* If we are not putting the new node as the root, than we are going to naviagte through the
            tree to the correct position.
             */
            Node<E> temp = new Node<E>(key,priority);
            tracker.add(priority);
            Stack<Node<E>> stack = new Stack<Node<E>>();
            Node<E> current = root;


            while(current != null) {
                /* Move through the BST and compare the keys as well as priorities through the format of a stack*/
                int compare_val = current.data.compareTo(key);
                if(compare_val == 0) {
                    return false;
                }else {
                    stack.push(current);
                    if(compare_val < 0) {
                        if(current.right == null) {
                            current.right = temp;
                            reheap(temp, stack);
                            return true;
                        }else {
                            current = current.right;
                        }
                    }else {
                        if(current.left == null) {
                            current.left = temp;
                            reheap(temp, stack);
                            return true;
                        }else {
                            current = current.left;
                        }
                    }
                }
            }
            return false;
        }
    }

    private void reheap(Node<E> current, Stack<Node<E>> length) {
        /*Through the addition of new nodes to the tree, the tree will lose its heap property.
        * This method will reorganize the tree in order to restore it's heap property by properly
        * organzining the tree based on both the key values and the priorities of the nodes. */
        while (!length.isEmpty()) {
            if (length.peek().priority < current.priority){
                Node<E> temp = length.pop(); //parent
                if (temp.left == current) {
                    if (length.isEmpty()) {
                        root = temp.rotateRight();
                    }
                    else if (length.peek().left == temp) {
                        length.peek().left = temp.rotateRight();
                    }else if (length.peek().right == temp) {
                        length.peek().right = temp.rotateRight();
                    }

                } else if (temp.right == current) {
                    if (length.isEmpty()) {
                        root = temp.rotateLeft();
                    }else if (length.peek().right == temp) {
                        length.peek().right = temp.rotateLeft();
                    }else if (length.peek().left == temp) {
                        length.peek().left = temp.rotateLeft();
                    }
                }
            } else {
                //return void
                return;
            }
        }
    }

    //Deletes the node with the given key and returns true if found
    public boolean delete(E key) {
        /* This method for delete, calls the greater delete method delete (Overloaded).
        This method's primary task is to check if the key actually exists within the node
        utilizing the method find, before actually deleting the node.

         */
        if(!find(key)) {
            //If the node with the specified key is not in the tree, then there is nothing to delete
            return false;
        }else {
            //if the node is in the tree, then call the overloaded delete method to delete said node.
            root = delete(root,key);
            return true;
        }
    }

    private Node<E> delete(Node<E> root,E key){
        /*This method is the main delete method. This method will search throughout
        * the three, and properly delete the node with the specified key. */
        if (root == null) {
            throw new IllegalStateException("The specified Key is not in this tree");
        } else {
            if (root.data.compareTo(key) < 0) {
                root.right = delete(root.right, key);
            } else {
                if (root.data.compareTo(key) > 0) {
                    root.left = delete(root.left, key);
                } else {
                    if (root.right == null) {
                        return root.left;
                    } else if (root.left == null) {
                        return root.left;
                    } else {
                        if (root.right.priority < root.left.priority) {
                            root = root.rotateRight();
                            root.right = delete(root.right, key);
                        } else {
                            root = root.rotateLeft();
                            root.left = delete(root.left, key);
                        }
                    }
                }
            }
        }
        return root;
    }



    private boolean find(Node<E> root, E key) {
        /* This overloaded find method returns whether or not the specified key is in the given BST*/
        if (root == null) {
            //if the root is null, there will be no other nodes in the tree.
            return false;
        }
        if (key.equals(root.data)) {
            //if the root has the data, than the key is at the root
            return true;
        }
        //These next two conditional statements than recursively search the tree left and right childs to find the key
        if (key.compareTo(root.data) < 0) {
            return find(root.left, key);
        } else {
            return find(root.right, key);
        }
    }



    public boolean find(E key) {
        //calls the overloaded find method
        return find(root, key);
    }


    //String builder / ToString method for printing out the tree
    private StringBuilder toString(Node<E> current, int node_level) {
        //This method utilzies a string builder object in order to create a string that will be output to the non overriden toString.
        StringBuilder node = new StringBuilder();
        //correct spacing for levels
        //"node" is a string that represents a node with a key and priority.
        for (int i=0; i<node_level; i++) {
            node.append("  ");
        }
        if (current==null) {
            node.append("null\n");
            return node;
        }
        node.append(current.toString()+"\n");

        node.append(toString(current.left,node_level+1));

        node.append(toString(current.right,node_level+1));
        return node;
    }


    public String toString() {
        /* This toString method utilzies an Overloaded toString with StringBuilder aswell as the toString in the Node
        Class in order to create the specified output from the HW4.PDF
         */
        return toString(root,0).toString();
    }




}

package Sulsenti;

import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertEquals;

class JUnit {


    @Test
    void constructor(){
        Treap<String> defaultTest = new Treap<>();

        //some assert on default values
        assertEquals("null\n", defaultTest.toString());

        Treap<String> secondTest = new Treap<>(5L);
        //some assert on second constructor values.
        assertEquals("null\n", secondTest.toString());

    }

    @Test
    void add_with_priority() {
        Treap<Integer> pri_test = new Treap<>();
        pri_test.add(1,2);
        assertEquals("(key=1, priority=2)\n  null\n  null\n", pri_test.toString());


    }

    @Test
    void add_no_priority() {
        Treap<Integer> no_pri_test = new Treap<>();
        no_pri_test.add(1);

        assertEquals(no_pri_test.toString().contains("key=1")==true, no_pri_test.toString().contains("key=1"));
    }

    @Test
    void delete() {
        Treap<Integer> del_test = new Treap<>();
        del_test.add(1);
        del_test.delete(1);
        assertEquals("null\n", del_test.toString());
    }

    @Test
    void find() {
        Treap<Integer> find_test = new Treap<>();

        find_test.add(1);
        find_test.add(2);
        find_test.add(3);
        find_test.add(4);
        assertEquals(find_test.find(4)==true, find_test.find(4));
    }



    @Test
    void testToString() {
        Treap<Integer> string_test = new Treap<>();
        string_test.add(1,2);
        assertEquals("(key=1, priority=2)\n  null\n  null\n", string_test.toString());
    }
}
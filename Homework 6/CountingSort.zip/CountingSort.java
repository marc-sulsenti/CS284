public class CountingSort {
    //Marc Sulsenti
    //I pledge my honor that I have abided by the Stevens Honor System
    public static void sort ( int [] A ){
        /*
        The purpose of the sort method is to sort a given array of integers using the Counting Sort
        method.
         */
        int length = A.length;
        if (length <= 1) {
            return;
        }
        // First, find the maximum element in the given array
        int max = A[0];
        for (int i = 1; i < length; i++) {
            if (A[i] > max) {
                max = A[i];
            }
        }
        int[] count = new int[max + 1];
        for (int i = 0; i < length; i++) {
            count[A[i]]++;
        }
        // Update the count array to store the actual position of each element
        for (int i = 1; i <= max; i++) {
            count[i] += count[i - 1];
        }
        // Create a temporary array to store the sorted elements
        int[] temp = new int[length];
        // Move through the input array from right to left and fill the temporary array with the newly sorted elements
        for (int i = length - 1; i >= 0; i--) {
            temp[--count[A[i]]] = A[i];
        }
        // Copy array
        for (int i = 0; i < length; i++) {
            A[i] = temp[i];
        }
    }
}

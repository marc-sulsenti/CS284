import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

//Marc Sulsenti
//I pledge my honor that I have abided by the Stevens Honor System
class CountingSortTest {


    @Test
    void sort() {
        //Initializing unsorted and sorted lists
        int[] test1_unsorted = {5,4,3,2,1};
        int[] test1_sorted = {1,2,3,4,5};

        int[] test2_unsorted = {100,95,90,85,80,75,70};
        int[] test2_sorted={70,75,80,85,90,95,100};

        int[] test3_unsorted = {53,23,21,76,88,0,120,43};
        int[] test3_sorted = {0,21,23,43,53,76,88,120};


        CountingSort obj = new CountingSort();
        obj.sort(test1_unsorted);
        obj.sort(test2_unsorted);
        obj.sort(test3_unsorted);
        assertArrayEquals(test1_sorted,test1_unsorted);
        assertArrayEquals(test2_sorted,test2_unsorted);
        assertArrayEquals(test3_sorted,test3_unsorted);
        //All three lists were sucessfully sorted if tests pass



    }
}